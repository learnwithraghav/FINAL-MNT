# MNT Automations 🚀

A production-ready AI-powered Gmail automation SaaS built with Next.js 15.

## Features
- 🔐 Google OAuth 2.0 (Sign in with Google)
- 📧 Gmail Integration (read, filter, reply)
- 🤖 AI Reply Generation (OpenRouter/GPT-4o-mini)
- 🎨 Gen-Z UI (glassmorphism, neon gradients, animations)
- ⚡ Auto-Reply System with ON/OFF toggle
- 📝 Prebuilt reply templates
- 📊 Reply logs & analytics
- 🔧 Tone control (Professional / Friendly / Short)

## Tech Stack
- **Framework**: Next.js 15 (App Router)
- **Auth**: NextAuth.js + Google OAuth
- **AI**: OpenRouter API (GPT-4o-mini)
- **Email**: Google Gmail API
- **UI**: Framer Motion, Lucide Icons

## Quick Start

```bash
# 1. Clone and install
git clone <your-repo>
cd mnt-automations
npm install

# 2. Set environment variables
cp .env.example .env.local
# Fill in your credentials in .env.local

# 3. Run locally
npm run dev
# Open http://localhost:3000
```

## Environment Variables

```env
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
NEXTAUTH_SECRET=any-random-string
NEXTAUTH_URL=http://localhost:3000
OPENAI_API_KEY=your-openrouter-api-key
OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
```

## Deploy on Vercel

1. Push code to GitHub
2. Import repo on [vercel.com](https://vercel.com)
3. Add all environment variables in Vercel Dashboard → Settings → Environment Variables
4. Set `NEXTAUTH_URL` to your Vercel domain (e.g. `https://mnt-automations.vercel.app`)
5. In Google Cloud Console, add your Vercel callback URL:
   `https://your-app.vercel.app/api/auth/callback/google`
6. Deploy! ✅

## Google Cloud Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a project → Enable Gmail API
3. Create OAuth 2.0 credentials
4. Add Authorized Redirect URIs:
   - `http://localhost:3000/api/auth/callback/google`
   - `https://your-app.vercel.app/api/auth/callback/google`

---

Built with ❤️ by MNT Automations
