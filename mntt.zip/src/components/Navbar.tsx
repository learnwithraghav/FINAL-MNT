"use client";

import { motion, AnimatePresence } from "framer-motion";
import { signIn, signOut, useSession } from "next-auth/react";
import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { Zap, LogOut, Menu, X, LayoutDashboard } from "lucide-react";

export default function Navbar() {
  const { data: session, status } = useSession();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <motion.nav
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        padding: "0 24px",
        height: 70,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        background: "rgba(3, 0, 20, 0.8)",
        backdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Logo */}
      <Link href="/" style={{ textDecoration: "none" }}>
        <motion.div
          whileHover={{ scale: 1.04 }}
          style={{ display: "flex", alignItems: "center", gap: 10 }}
        >
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: 10,
              background: "linear-gradient(135deg, #00f3ff, #b026ff)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 0 20px rgba(0,243,255,0.4)",
            }}
          >
            <Zap size={18} color="white" fill="white" />
          </div>
          <span
            style={{
              fontFamily: "var(--font-space)",
              fontWeight: 700,
              fontSize: 18,
              background: "linear-gradient(135deg, #ffffff, #a0a0ff)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            MNT Automations
          </span>
        </motion.div>
      </Link>

      {/* Desktop nav */}
      <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
        {status === "loading" ? (
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: "50%",
              border: "2px solid rgba(0,243,255,0.3)",
              borderTopColor: "#00f3ff",
              animation: "spin 1s linear infinite",
            }}
          />
        ) : session ? (
          <>
            <Link href="/dashboard" style={{ textDecoration: "none" }}>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  padding: "8px 18px",
                  borderRadius: 10,
                  border: "1px solid rgba(0,243,255,0.3)",
                  background: "rgba(0,243,255,0.08)",
                  color: "#00f3ff",
                  cursor: "pointer",
                  fontSize: 14,
                  fontWeight: 500,
                }}
              >
                <LayoutDashboard size={15} />
                Dashboard
              </motion.button>
            </Link>
            <motion.div
              whileHover={{ scale: 1.05 }}
              style={{ display: "flex", alignItems: "center", gap: 10 }}
            >
              {session.user?.image && (
                <Image
                  src={session.user.image}
                  alt={session.user.name || "User"}
                  width={34}
                  height={34}
                  style={{ borderRadius: "50%", border: "2px solid rgba(176,38,255,0.5)" }}
                />
              )}
              <span style={{ fontSize: 14, color: "rgba(255,255,255,0.7)" }}>
                {session.user?.name?.split(" ")[0]}
              </span>
            </motion.div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => signOut()}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                padding: "8px 14px",
                borderRadius: 10,
                border: "1px solid rgba(255,45,120,0.3)",
                background: "rgba(255,45,120,0.08)",
                color: "#ff2d78",
                cursor: "pointer",
                fontSize: 14,
                fontWeight: 500,
              }}
            >
              <LogOut size={14} />
              Sign Out
            </motion.button>
          </>
        ) : (
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(0,243,255,0.4)" }}
            whileTap={{ scale: 0.95 }}
            onClick={() => signIn("google")}
            style={{
              padding: "9px 22px",
              borderRadius: 10,
              border: "none",
              background: "linear-gradient(135deg, #00f3ff, #b026ff)",
              color: "white",
              cursor: "pointer",
              fontWeight: 600,
              fontSize: 14,
              letterSpacing: "0.3px",
            }}
          >
            Sign in with Google
          </motion.button>
        )}
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </motion.nav>
  );
}
