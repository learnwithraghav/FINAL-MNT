"use client";

import { SessionProvider } from "next-auth/react";
import { ReactNode } from "react";
import dynamic from "next/dynamic";

const CursorEffect = dynamic(
  () => import("./CursorEffect").then((m) => m.CursorEffect),
  { ssr: false }
);

export function Providers({ children }: { children: ReactNode }) {
  return (
    <SessionProvider>
      <CursorEffect />
      {children}
    </SessionProvider>
  );
}
