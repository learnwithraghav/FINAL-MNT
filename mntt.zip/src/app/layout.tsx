import type { Metadata } from "next";
import { Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/Providers";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space",
});

export const metadata: Metadata = {
  title: "MNT Automations | AI-Powered Gmail Auto-Reply",
  description:
    "Automate your Gmail replies with AI. Professional, friendly, or short — MNT Automations handles it all with one click.",
  keywords: ["gmail automation", "ai reply", "email automation", "mnt automations"],
  openGraph: {
    title: "MNT Automations",
    description: "AI-Powered Gmail Auto-Reply System",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="bg-[#030014] text-white antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
