"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { signIn, useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import {
  Bot, Mail, Zap, Shield, Sparkles, Settings2, ArrowRight, CheckCircle,
} from "lucide-react";

const features = [
  {
    icon: <Bot size={24} />,
    title: "AI Auto Reply",
    description: "Generate smart, context-aware email replies using GPT-4 via OpenRouter.",
    color: "#00f3ff",
    badge: "Powered by AI",
  },
  {
    icon: <Mail size={24} />,
    title: "Gmail Integration",
    description: "Read, filter & respond to emails across Important, Promotions & Social.",
    color: "#b026ff",
    badge: "Gmail API",
  },
  {
    icon: <Zap size={24} />,
    title: "Auto-Send Replies",
    description: "Set it and forget it — replies go out automatically with your signature.",
    color: "#ff2d78",
    badge: "Automation",
  },
  {
    icon: <Shield size={24} />,
    title: "Secure Auth",
    description: "OAuth 2.0 Google sign-in. Your data stays private & encrypted.",
    color: "#00ff9d",
    badge: "OAuth 2.0",
  },
  {
    icon: <Sparkles size={24} />,
    title: "Smart Templates",
    description: "Choose from prebuilt templates or craft AI-powered custom responses.",
    color: "#ffb800",
    badge: "Templates",
  },
  {
    icon: <Settings2 size={24} />,
    title: "Full Control",
    description: "Delay timers, tone settings, filter rules & toggle automation on/off.",
    color: "#7c3aed",
    badge: "Controls",
  },
];

const stats = [
  { value: "10x", label: "Faster Replies" },
  { value: "99%", label: "Uptime" },
  { value: "∞", label: "Emails Handled" },
  { value: "0", label: "Manual Effort" },
];

export default function HomePage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Particle animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: { x: number; y: number; vx: number; vy: number; size: number; alpha: number; color: string }[] = [];
    const colors = ["#00f3ff", "#b026ff", "#ff2d78", "#7c3aed"];

    for (let i = 0; i < 80; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        size: Math.random() * 2 + 0.5,
        alpha: Math.random() * 0.5 + 0.1,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }

    let animId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height;
        if (p.y > canvas.height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color + Math.floor(p.alpha * 255).toString(16).padStart(2, "0");
        ctx.fill();
      });
      animId = requestAnimationFrame(animate);
    };
    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const handleStartAutomation = () => {
    if (status === "loading") return;
    if (session) {
      router.push("/dashboard");
    } else {
      signIn("google", { callbackUrl: "/dashboard" });
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#030014", position: "relative", overflow: "hidden" }}>
      {/* Particle canvas */}
      <canvas
        ref={canvasRef}
        style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}
      />

      {/* Background orbs */}
      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{
          position: "absolute", top: "10%", left: "15%",
          width: 500, height: 500, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(176,38,255,0.12) 0%, transparent 70%)",
          filter: "blur(40px)",
        }} />
        <div style={{
          position: "absolute", bottom: "20%", right: "10%",
          width: 400, height: 400, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(0,243,255,0.1) 0%, transparent 70%)",
          filter: "blur(40px)",
        }} />
        <div style={{
          position: "absolute", top: "50%", left: "50%",
          transform: "translate(-50%, -50%)",
          width: 600, height: 600, borderRadius: "50%",
          background: "radial-gradient(circle, rgba(255,45,120,0.06) 0%, transparent 70%)",
          filter: "blur(60px)",
        }} />
      </div>

      <Navbar />

      {/* Hero Section */}
      <section style={{ position: "relative", zIndex: 1, paddingTop: 160, paddingBottom: 100, textAlign: "center", padding: "160px 24px 100px" }}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <div style={{ display: "flex", justifyContent: "center", marginBottom: 24 }}>
            <span className="badge badge-blue" style={{ fontSize: 13 }}>
              <Sparkles size={12} />
              AI-Powered Email Automation
            </span>
          </div>

          <h1 style={{
            fontFamily: "var(--font-space)",
            fontSize: "clamp(42px, 7vw, 90px)",
            fontWeight: 800,
            lineHeight: 1.05,
            marginBottom: 28,
            letterSpacing: "-2px",
          }}>
            <span style={{ color: "white" }}>Automate Your</span>
            <br />
            <span className="gradient-text">Gmail Replies</span>
            <br />
            <span style={{ color: "rgba(255,255,255,0.6)", fontSize: "0.85em" }}>with AI Power</span>
          </h1>

          <p style={{
            fontSize: "clamp(16px, 2vw, 20px)",
            color: "rgba(255,255,255,0.55)",
            maxWidth: 560,
            margin: "0 auto 48px",
            lineHeight: 1.7,
          }}>
            Connect Gmail, pick your tone, and let MNT Automations handle every reply — professionally, instantly, automatically.
          </p>

          <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
            <motion.button
              id="start-automation-btn"
              whileHover={{ scale: 1.06, boxShadow: "0 0 50px rgba(0,243,255,0.5)" }}
              whileTap={{ scale: 0.96 }}
              onClick={handleStartAutomation}
              style={{
                padding: "16px 40px",
                borderRadius: 14,
                border: "none",
                background: "linear-gradient(135deg, #00f3ff, #b026ff, #ff2d78)",
                backgroundSize: "200% 200%",
                color: "white",
                fontSize: 18,
                fontWeight: 700,
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 10,
                letterSpacing: "0.3px",
                boxShadow: "0 0 30px rgba(0,243,255,0.3)",
              }}
            >
              <Zap size={20} fill="white" />
              Start Automation
              <ArrowRight size={18} />
            </motion.button>

            <motion.a
              href="#features"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              style={{
                padding: "16px 32px",
                borderRadius: 14,
                border: "1px solid rgba(255,255,255,0.12)",
                background: "rgba(255,255,255,0.04)",
                color: "rgba(255,255,255,0.8)",
                fontSize: 18,
                fontWeight: 600,
                cursor: "pointer",
                textDecoration: "none",
                display: "flex",
                alignItems: "center",
                gap: 8,
              }}
            >
              See Features
            </motion.a>
          </div>
        </motion.div>

        {/* Stats bar */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.7 }}
          style={{
            display: "flex",
            justifyContent: "center",
            gap: "clamp(24px, 5vw, 64px)",
            marginTop: 72,
            flexWrap: "wrap",
          }}
        >
          {stats.map((stat) => (
            <div key={stat.label} style={{ textAlign: "center" }}>
              <div style={{
                fontSize: "clamp(28px, 4vw, 44px)",
                fontWeight: 800,
                fontFamily: "var(--font-space)",
                background: "linear-gradient(135deg, #00f3ff, #b026ff)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}>{stat.value}</div>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginTop: 4 }}>{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </section>

      {/* Features Section */}
      <section id="features" style={{ position: "relative", zIndex: 1, padding: "80px 24px", maxWidth: 1200, margin: "0 auto" }}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          style={{ textAlign: "center", marginBottom: 60 }}
        >
          <h2 style={{
            fontFamily: "var(--font-space)",
            fontSize: "clamp(28px, 4vw, 48px)",
            fontWeight: 700,
            color: "white",
            marginBottom: 16,
          }}>
            Everything You Need to{" "}
            <span className="gradient-text-purple">Automate</span>
          </h2>
          <p style={{ color: "rgba(255,255,255,0.45)", fontSize: 17 }}>
            Six powerful features working together seamlessly.
          </p>
        </motion.div>

        <div className="grid-auto">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.5 }}
              whileHover={{ y: -6, scale: 1.02 }}
              className="glass"
              style={{ padding: 28, cursor: "default", transition: "background 0.3s" }}
            >
              <div style={{
                width: 50, height: 50, borderRadius: 12,
                background: `${feature.color}18`,
                border: `1px solid ${feature.color}30`,
                display: "flex", alignItems: "center", justifyContent: "center",
                color: feature.color, marginBottom: 18,
              }}>
                {feature.icon}
              </div>
              <div style={{ marginBottom: 10 }}>
                <span className="badge" style={{
                  background: `${feature.color}10`,
                  color: feature.color,
                  border: `1px solid ${feature.color}25`,
                  fontSize: 11,
                }}>
                  {feature.badge}
                </span>
              </div>
              <h3 style={{ fontSize: 18, fontWeight: 700, color: "white", marginBottom: 10 }}>
                {feature.title}
              </h3>
              <p style={{ fontSize: 14, color: "rgba(255,255,255,0.5)", lineHeight: 1.7 }}>
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section style={{ position: "relative", zIndex: 1, padding: "80px 24px 120px", textAlign: "center" }}>
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="glass"
          style={{
            maxWidth: 700,
            margin: "0 auto",
            padding: "60px 40px",
            borderRadius: 24,
            background: "linear-gradient(135deg, rgba(0,243,255,0.05), rgba(176,38,255,0.05))",
            border: "1px solid rgba(176,38,255,0.2)",
          }}
        >
          <div style={{ fontSize: 48, marginBottom: 16 }}>⚡</div>
          <h2 style={{
            fontFamily: "var(--font-space)",
            fontSize: "clamp(24px, 4vw, 40px)",
            fontWeight: 700,
            color: "white",
            marginBottom: 16,
          }}>
            Ready to Automate?
          </h2>
          <p style={{ color: "rgba(255,255,255,0.5)", marginBottom: 36, fontSize: 16 }}>
            Sign in with Google and connect your Gmail in under 60 seconds.
          </p>
          <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", marginBottom: 28 }}>
            {["No credit card", "Free to start", "Cancel anytime"].map((item) => (
              <div key={item} style={{ display: "flex", alignItems: "center", gap: 6, color: "rgba(255,255,255,0.5)", fontSize: 14 }}>
                <CheckCircle size={14} color="#00ff9d" />
                {item}
              </div>
            ))}
          </div>
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: "0 0 40px rgba(176,38,255,0.5)" }}
            whileTap={{ scale: 0.95 }}
            onClick={handleStartAutomation}
            style={{
              padding: "14px 36px",
              borderRadius: 12,
              border: "none",
              background: "linear-gradient(135deg, #b026ff, #00f3ff)",
              color: "white",
              fontSize: 16,
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Get Started — It&apos;s Free
          </motion.button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer style={{
        borderTop: "1px solid rgba(255,255,255,0.06)",
        padding: "28px 24px",
        textAlign: "center",
        color: "rgba(255,255,255,0.25)",
        fontSize: 13,
        position: "relative",
        zIndex: 1,
      }}>
        © 2024 MNT Automations. Built with Next.js & OpenRouter AI.
      </footer>
    </div>
  );
}
