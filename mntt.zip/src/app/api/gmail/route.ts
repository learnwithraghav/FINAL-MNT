import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "../auth/[...nextauth]/route";
import { google } from "googleapis";

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.accessToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category") || "INBOX";
  const maxResults = parseInt(searchParams.get("maxResults") || "20");

  try {
    const auth = new google.auth.OAuth2();
    auth.setCredentials({ access_token: session.accessToken });
    const gmail = google.gmail({ version: "v1", auth });

    // Map category to label
    const labelMap: Record<string, string> = {
      INBOX: "INBOX",
      IMPORTANT: "IMPORTANT",
      PROMOTIONS: "CATEGORY_PROMOTIONS",
      SOCIAL: "CATEGORY_SOCIAL",
    };
    const label = labelMap[category.toUpperCase()] || "INBOX";

    const listRes = await gmail.users.messages.list({
      userId: "me",
      labelIds: [label],
      maxResults,
    });

    const messages = listRes.data.messages || [];

    const emails = await Promise.all(
      messages.slice(0, 10).map(async (msg) => {
        const detail = await gmail.users.messages.get({
          userId: "me",
          id: msg.id!,
          format: "metadata",
          metadataHeaders: ["From", "Subject", "Date"],
        });

        const headers = detail.data.payload?.headers || [];
        const getHeader = (name: string) =>
          headers.find((h) => h.name === name)?.value || "";

        return {
          id: msg.id,
          threadId: msg.threadId,
          subject: getHeader("Subject") || "(No subject)",
          from: getHeader("From"),
          date: getHeader("Date"),
          snippet: detail.data.snippet || "",
          labelIds: detail.data.labelIds || [],
          isRead: !detail.data.labelIds?.includes("UNREAD"),
        };
      })
    );

    return NextResponse.json({ emails, total: messages.length });
  } catch (error: any) {
    console.error("Gmail API error:", error?.message);
    return NextResponse.json(
      { error: "Failed to fetch emails", details: error?.message },
      { status: 500 }
    );
  }
}
