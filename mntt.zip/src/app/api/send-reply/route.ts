import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "../auth/[...nextauth]/route";
import { google } from "googleapis";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.accessToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const { to, subject, replyBody, threadId } = body;

  if (!to || !replyBody) {
    return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
  }

  try {
    const auth = new google.auth.OAuth2();
    auth.setCredentials({ access_token: session.accessToken });
    const gmail = google.gmail({ version: "v1", auth });

    const emailLines = [
      `To: ${to}`,
      `Subject: Re: ${subject || ""}`,
      "Content-Type: text/plain; charset=utf-8",
      "MIME-Version: 1.0",
      "",
      replyBody,
    ];

    if (threadId) {
      emailLines.splice(2, 0, `In-Reply-To: ${threadId}`, `References: ${threadId}`);
    }

    const emailContent = emailLines.join("\n");
    const encodedEmail = Buffer.from(emailContent)
      .toString("base64")
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");

    await gmail.users.messages.send({
      userId: "me",
      requestBody: {
        raw: encodedEmail,
        threadId: threadId || undefined,
      },
    });

    // Log the sent reply
    const logEntry = {
      id: Date.now().toString(),
      to,
      subject,
      sentAt: new Date().toISOString(),
      preview: replyBody.substring(0, 100),
    };

    return NextResponse.json({ success: true, log: logEntry });
  } catch (error: any) {
    console.error("Send reply error:", error?.message);
    return NextResponse.json(
      { error: "Failed to send reply", details: error?.message },
      { status: 500 }
    );
  }
}
