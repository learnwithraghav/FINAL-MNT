import { NextResponse } from "next/server";
import { getServerSession } from "next-auth/next";
import { authOptions } from "../auth/[...nextauth]/route";

const TONE_PROMPTS: Record<string, string> = {
  professional: "Write a professional, formal, concise email reply. Be respectful and clear.",
  friendly: "Write a warm, friendly email reply. Sound helpful and personable.",
  short: "Write a very brief, direct reply in 1-2 sentences maximum.",
};

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return NextResponse.json({ error: "AI API key not configured" }, { status: 500 });
  }

  const body = await req.json();
  const { emailSubject, emailFrom, emailSnippet, tone = "professional" } = body;

  if (!emailSnippet) {
    return NextResponse.json({ error: "Email content is required" }, { status: 400 });
  }

  const toneInstruction = TONE_PROMPTS[tone] || TONE_PROMPTS.professional;

  const prompt = `${toneInstruction}

Original Email:
From: ${emailFrom || "Unknown sender"}
Subject: ${emailSubject || "No subject"}
Content: ${emailSnippet}

Write only the reply body. Do not include subject line or salutation prefix like "Re:". End with:

— Sent via MNT Automations`;

  try {
    const baseUrl = process.env.OPENROUTER_BASE_URL || "https://openrouter.ai/api/v1";
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
        "HTTP-Referer": process.env.NEXTAUTH_URL || "http://localhost:3000",
        "X-Title": "MNT Automations",
      },
      body: JSON.stringify({
        model: "openai/gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: "You are an expert email assistant for MNT Automations. Generate professional, contextual email replies.",
          },
          { role: "user", content: prompt },
        ],
        max_tokens: 400,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenRouter API error: ${response.status} - ${errText}`);
    }

    const data = await response.json();
    const reply =
      data.choices?.[0]?.message?.content?.trim() ||
      "Unable to generate reply. Please try again.";

    return NextResponse.json({ reply, tone, model: data.model });
  } catch (error: any) {
    console.error("AI reply error:", error?.message);
    return NextResponse.json(
      { error: "Failed to generate AI reply", details: error?.message },
      { status: 500 }
    );
  }
}
