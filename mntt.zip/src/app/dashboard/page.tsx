"use client";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useSession, signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Navbar from "@/components/Navbar";
import {
  Mail, Bot, Zap, ToggleLeft, ToggleRight, Clock, Filter,
  Sparkles, Send, RefreshCw, CheckCircle, AlertCircle,
  BarChart2, FileText, ChevronDown, LogIn,
} from "lucide-react";

const TEMPLATES = [
  { id: "t1", label: "Acknowledge & Review", text: "Thank you for your email. I have received your message and will review it shortly. I will get back to you as soon as possible.\n\n— Sent via MNT Automations" },
  { id: "t2", label: "Meeting Request", text: "Thank you for reaching out! I'd be happy to connect. Please feel free to share your availability and we can schedule a time that works for both of us.\n\n— Sent via MNT Automations" },
  { id: "t3", label: "Out of Office", text: "Thank you for your email. I am currently out of the office and will respond upon my return. For urgent matters, please contact my team.\n\n— Sent via MNT Automations" },
  { id: "t4", label: "Quick Thanks", text: "Thank you for getting in touch! I appreciate you reaching out and will respond with more detail soon.\n\n— Sent via MNT Automations" },
];

type Email = {
  id: string;
  threadId: string;
  subject: string;
  from: string;
  date: string;
  snippet: string;
  isRead: boolean;
};

type LogEntry = { id: string; to: string; subject: string; sentAt: string; preview: string; };

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const [autoMode, setAutoMode] = useState(false);
  const [replyMode, setReplyMode] = useState<"manual" | "ai">("manual");
  const [tone, setTone] = useState<"professional" | "friendly" | "short">("professional");
  const [category, setCategory] = useState("INBOX");
  const [delay, setDelay] = useState(5);
  const [activeTab, setActiveTab] = useState("emails");

  const [emails, setEmails] = useState<Email[]>([]);
  const [emailsLoading, setEmailsLoading] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [replyText, setReplyText] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [sendLoading, setSendLoading] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: "success" | "error" } | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState("");

  useEffect(() => {
    if (status === "unauthenticated") router.push("/");
  }, [status, router]);

  const showToast = (msg: string, type: "success" | "error" = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const fetchEmails = async () => {
    setEmailsLoading(true);
    try {
      const res = await fetch(`/api/gmail?category=${category}&maxResults=15`);
      const data = await res.json();
      if (data.emails) setEmails(data.emails);
      else showToast(data.error || "Failed to load emails", "error");
    } catch {
      showToast("Network error fetching emails", "error");
    }
    setEmailsLoading(false);
  };

  const generateAiReply = async () => {
    if (!selectedEmail) return;
    setAiLoading(true);
    try {
      const res = await fetch("/api/ai-reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          emailSubject: selectedEmail.subject,
          emailFrom: selectedEmail.from,
          emailSnippet: selectedEmail.snippet,
          tone,
        }),
      });
      const data = await res.json();
      if (data.reply) setReplyText(data.reply);
      else showToast(data.error || "AI failed", "error");
    } catch {
      showToast("AI generation failed", "error");
    }
    setAiLoading(false);
  };

  const sendReply = async () => {
    if (!selectedEmail || !replyText.trim()) return;
    setSendLoading(true);
    try {
      const toMatch = selectedEmail.from.match(/<(.+?)>/);
      const to = toMatch ? toMatch[1] : selectedEmail.from;
      const res = await fetch("/api/send-reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to,
          subject: selectedEmail.subject,
          replyBody: replyText,
          threadId: selectedEmail.threadId,
        }),
      });
      const data = await res.json();
      if (data.success) {
        showToast("Reply sent successfully!");
        if (data.log) setLogs((prev) => [data.log, ...prev]);
        setReplyText("");
        setSelectedEmail(null);
      } else {
        showToast(data.error || "Failed to send", "error");
      }
    } catch {
      showToast("Send failed", "error");
    }
    setSendLoading(false);
  };

  const applyTemplate = (id: string) => {
    const t = TEMPLATES.find((x) => x.id === id);
    if (t) { setReplyText(t.text); setSelectedTemplate(id); }
  };

  if (status === "loading") {
    return (
      <div style={{ minHeight: "100vh", background: "#030014", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ width: 48, height: 48, borderRadius: "50%", border: "3px solid rgba(0,243,255,0.2)", borderTopColor: "#00f3ff", animation: "spin 0.8s linear infinite" }} />
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      </div>
    );
  }

  if (!session) return null;

  const card: React.CSSProperties = {
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.08)",
    borderRadius: 16,
    padding: 24,
    marginBottom: 20,
  };

  const pill = (active: boolean, color = "#00f3ff"): React.CSSProperties => ({
    padding: "7px 18px", borderRadius: 10, border: `1px solid ${active ? color : "rgba(255,255,255,0.1)"}`,
    background: active ? `${color}18` : "transparent", color: active ? color : "rgba(255,255,255,0.5)",
    cursor: "pointer", fontSize: 13, fontWeight: 500, transition: "all 0.2s",
  });

  const btn = (gradient: string): React.CSSProperties => ({
    padding: "10px 22px", borderRadius: 10, border: "none",
    background: gradient, color: "white", cursor: "pointer",
    fontWeight: 600, fontSize: 14, display: "flex", alignItems: "center", gap: 8,
  });

  return (
    <div style={{ minHeight: "100vh", background: "#030014", paddingTop: 70 }}>
      <Navbar />
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
            style={{ position: "fixed", top: 80, right: 24, zIndex: 999, padding: "12px 20px", borderRadius: 12,
              background: toast.type === "success" ? "rgba(0,255,157,0.15)" : "rgba(255,45,120,0.15)",
              border: `1px solid ${toast.type === "success" ? "rgba(0,255,157,0.3)" : "rgba(255,45,120,0.3)"}`,
              color: toast.type === "success" ? "#00ff9d" : "#ff2d78",
              display: "flex", alignItems: "center", gap: 8, fontSize: 14, fontWeight: 500,
            }}>
            {toast.type === "success" ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
            {toast.msg}
          </motion.div>
        )}
      </AnimatePresence>

      <div style={{ maxWidth: 1280, margin: "0 auto", padding: "32px 24px" }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 32, flexWrap: "wrap", gap: 16 }}>
          <div>
            <h1 style={{ fontSize: 28, fontWeight: 800, color: "white", marginBottom: 4 }}>
              Welcome, {session.user?.name?.split(" ")[0]} 👋
            </h1>
            <p style={{ color: "rgba(255,255,255,0.4)", fontSize: 14 }}>{session.user?.email}</p>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 14, color: autoMode ? "#00ff9d" : "rgba(255,255,255,0.4)" }}>
              Auto-Reply {autoMode ? "ON" : "OFF"}
            </span>
            <label className="toggle-switch" style={{ cursor: "pointer" }}>
              <input type="checkbox" checked={autoMode} onChange={(e) => { setAutoMode(e.target.checked); showToast(e.target.checked ? "Auto-reply enabled!" : "Auto-reply disabled"); }} />
              <span className="toggle-slider" />
            </label>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 16, marginBottom: 28 }}>
          {[
            { label: "Emails Loaded", value: emails.length, color: "#00f3ff", icon: <Mail size={18} /> },
            { label: "Replies Sent", value: logs.length, color: "#00ff9d", icon: <Send size={18} /> },
            { label: "Mode", value: replyMode === "ai" ? "AI" : "Manual", color: "#b026ff", icon: <Bot size={18} /> },
            { label: "Auto-Reply", value: autoMode ? "Active" : "Paused", color: autoMode ? "#00ff9d" : "#ff2d78", icon: <Zap size={18} /> },
          ].map((s) => (
            <div key={s.label} style={{ ...card, marginBottom: 0, display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ width: 42, height: 42, borderRadius: 10, background: `${s.color}18`, border: `1px solid ${s.color}30`, display: "flex", alignItems: "center", justifyContent: "center", color: s.color }}>{s.icon}</div>
              <div>
                <div style={{ fontSize: 20, fontWeight: 800, color: "white" }}>{s.value}</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)" }}>{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "300px 1fr", gap: 24 }}>
          {/* Left Panel */}
          <div>
            {/* Mode */}
            <div style={card}>
              <h3 style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 1, marginBottom: 14 }}>Automation Mode</h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {(["manual", "ai"] as const).map((m) => (
                  <button key={m} onClick={() => setReplyMode(m)} style={{ ...pill(replyMode === m, m === "ai" ? "#b026ff" : "#00f3ff"), display: "flex", alignItems: "center", gap: 8 }}>
                    {m === "ai" ? <Bot size={14} /> : <Mail size={14} />}
                    {m === "manual" ? "Manual Reply" : "AI Auto Reply"}
                  </button>
                ))}
              </div>
            </div>

            {/* Tone */}
            {replyMode === "ai" && (
              <div style={card}>
                <h3 style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 1, marginBottom: 14 }}>AI Tone</h3>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {(["professional", "friendly", "short"] as const).map((t) => (
                    <button key={t} onClick={() => setTone(t)} style={pill(tone === t, "#b026ff")}>
                      {t.charAt(0).toUpperCase() + t.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Controls */}
            <div style={card}>
              <h3 style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 1, marginBottom: 14 }}>Controls</h3>
              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
                  <Filter size={13} /> Filter Category
                </label>
                <select value={category} onChange={(e) => setCategory(e.target.value)}
                  style={{ width: "100%", padding: "8px 12px", borderRadius: 8, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "white", fontSize: 13 }}>
                  {["INBOX", "IMPORTANT", "PROMOTIONS", "SOCIAL"].map((c) => <option key={c} value={c} style={{ background: "#0d0d2b" }}>{c}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 13, color: "rgba(255,255,255,0.5)", display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
                  <Clock size={13} /> Delay: {delay}s
                </label>
                <input type="range" min={1} max={60} value={delay} onChange={(e) => setDelay(Number(e.target.value))}
                  style={{ width: "100%", accentColor: "#00f3ff" }} />
              </div>
            </div>

            {/* Templates */}
            <div style={card}>
              <h3 style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 1, marginBottom: 14 }}>
                <FileText size={13} style={{ display: "inline", marginRight: 6 }} />Templates
              </h3>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {TEMPLATES.map((t) => (
                  <button key={t.id} onClick={() => applyTemplate(t.id)} style={pill(selectedTemplate === t.id, "#ffb800")}>
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Panel */}
          <div>
            {/* Tabs */}
            <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
              {[["emails", "Emails", <Mail size={14} key="m" />], ["compose", "Compose Reply", <Send size={14} key="s" />], ["logs", "Reply Logs", <BarChart2 size={14} key="b" />]].map(([id, label, icon]) => (
                <button key={id as string} onClick={() => setActiveTab(id as string)} style={{ ...pill(activeTab === id, "#00f3ff"), display: "flex", alignItems: "center", gap: 6 }}>
                  {icon}{label}
                </button>
              ))}
            </div>

            {/* Emails Tab */}
            {activeTab === "emails" && (
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                  <h2 style={{ fontSize: 18, fontWeight: 700, color: "white" }}>Gmail Inbox</h2>
                  <button onClick={fetchEmails} disabled={emailsLoading} style={btn("linear-gradient(135deg,#00f3ff,#0080ff)")}>
                    <RefreshCw size={14} style={{ animation: emailsLoading ? "spin 0.8s linear infinite" : "none" }} />
                    {emailsLoading ? "Loading..." : "Load Emails"}
                  </button>
                </div>
                {emails.length === 0 ? (
                  <div style={{ ...card, textAlign: "center", padding: 60 }}>
                    <Mail size={40} color="rgba(255,255,255,0.15)" style={{ margin: "0 auto 16px" }} />
                    <p style={{ color: "rgba(255,255,255,0.3)", fontSize: 15 }}>Click &quot;Load Emails&quot; to fetch your Gmail</p>
                  </div>
                ) : (
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {emails.map((email) => (
                      <motion.div key={email.id} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}
                        whileHover={{ scale: 1.01 }} onClick={() => { setSelectedEmail(email); setActiveTab("compose"); setReplyText(""); setSelectedTemplate(""); }}
                        style={{ ...card, marginBottom: 0, cursor: "pointer", borderColor: selectedEmail?.id === email.id ? "rgba(0,243,255,0.4)" : "rgba(255,255,255,0.08)" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                          <span style={{ fontSize: 14, fontWeight: email.isRead ? 400 : 700, color: "white", flex: 1, marginRight: 12, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                            {email.subject}
                          </span>
                          <span style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", whiteSpace: "nowrap" }}>
                            {new Date(email.date).toLocaleDateString()}
                          </span>
                        </div>
                        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 4 }}>{email.from}</div>
                        <div style={{ fontSize: 13, color: "rgba(255,255,255,0.35)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{email.snippet}</div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Compose Tab */}
            {activeTab === "compose" && (
              <div>
                <h2 style={{ fontSize: 18, fontWeight: 700, color: "white", marginBottom: 16 }}>Compose Reply</h2>
                {!selectedEmail ? (
                  <div style={{ ...card, textAlign: "center", padding: 60 }}>
                    <p style={{ color: "rgba(255,255,255,0.3)" }}>Select an email from the Emails tab first</p>
                  </div>
                ) : (
                  <>
                    <div style={{ ...card, marginBottom: 16, borderColor: "rgba(0,243,255,0.2)" }}>
                      <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginBottom: 4 }}>Replying to:</div>
                      <div style={{ fontWeight: 700, color: "white", marginBottom: 4, fontSize: 15 }}>{selectedEmail.subject}</div>
                      <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginBottom: 8 }}>{selectedEmail.from}</div>
                      <div style={{ fontSize: 13, color: "rgba(255,255,255,0.3)", padding: "10px 14px", background: "rgba(255,255,255,0.04)", borderRadius: 8 }}>{selectedEmail.snippet}</div>
                    </div>
                    {replyMode === "ai" && (
                      <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }} onClick={generateAiReply} disabled={aiLoading}
                        style={{ ...btn("linear-gradient(135deg,#b026ff,#ff2d78)"), marginBottom: 16, opacity: aiLoading ? 0.7 : 1 }}>
                        <Sparkles size={15} style={{ animation: aiLoading ? "spin 1s linear infinite" : "none" }} />
                        {aiLoading ? "Generating..." : `Generate AI Reply (${tone})`}
                      </motion.button>
                    )}
                    <textarea value={replyText} onChange={(e) => setReplyText(e.target.value)} placeholder="Write your reply here..."
                      style={{ width: "100%", minHeight: 200, padding: "14px 16px", borderRadius: 12, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "white", fontSize: 14, lineHeight: 1.7, resize: "vertical", outline: "none", fontFamily: "inherit", marginBottom: 16 }} />
                    <div style={{ fontSize: 12, color: "rgba(255,255,255,0.25)", marginBottom: 16 }}>Signature: — Sent via MNT Automations</div>
                    <motion.button whileHover={{ scale: 1.03, boxShadow: "0 0 30px rgba(0,243,255,0.4)" }} whileTap={{ scale: 0.97 }}
                      onClick={sendReply} disabled={sendLoading || !replyText.trim()}
                      style={{ ...btn("linear-gradient(135deg,#00f3ff,#0080ff)"), opacity: !replyText.trim() ? 0.5 : 1 }}>
                      <Send size={15} />
                      {sendLoading ? "Sending..." : "Send Reply"}
                    </motion.button>
                  </>
                )}
              </div>
            )}

            {/* Logs Tab */}
            {activeTab === "logs" && (
              <div>
                <h2 style={{ fontSize: 18, fontWeight: 700, color: "white", marginBottom: 16 }}>Reply Logs</h2>
                {logs.length === 0 ? (
                  <div style={{ ...card, textAlign: "center", padding: 60 }}>
                    <BarChart2 size={40} color="rgba(255,255,255,0.15)" style={{ margin: "0 auto 16px" }} />
                    <p style={{ color: "rgba(255,255,255,0.3)" }}>No replies sent yet. Send your first reply!</p>
                  </div>
                ) : (
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {logs.map((log) => (
                      <motion.div key={log.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={card}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                          <span style={{ fontSize: 14, fontWeight: 600, color: "white" }}>{log.subject}</span>
                          <span className="badge badge-green" style={{ fontSize: 11 }}><CheckCircle size={10} /> Sent</span>
                        </div>
                        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 6 }}>To: {log.to}</div>
                        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)" }}>{new Date(log.sentAt).toLocaleString()}</div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
